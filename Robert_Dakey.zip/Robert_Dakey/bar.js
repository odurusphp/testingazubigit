const ARRAY_LENGTH = 12;
const monthlySales = [];

// Randomly generating the monthly sales
for (let i = 0; i < ARRAY_LENGTH; i++) {
    monthlySales.push(Math.floor( Math.random() * (1 - 1 + 100)) + 1 );
}
/*
for (let i = 0; i < ARRAY_LENGTH; i++) {
console.log(monthlySales[i] + "");
}
*/
// BArchart display of the sales
var chartData = {
    type: 'bar',

    plotarea: {
        'adjust-layout': true
      },
          'scale-x': { /* Scale object */
        /*'min-value': 1420070400000,
        step: "month",
        transform: {
            type: "date",
            all: "%M"
        }*/
        label: {// Scale Title
            text: "Monthly Sales for 12 months",
        },
        labels: ["Jan", "Feb", "March", "April", "May", "June", "July", "Aug", "Sept", "Oct", "Nov", "Dec"]
    },
    plot: {
        'border-radius': "3px", /* Rounded Corners */
      },

    series: [
     /*{   values: [20, 30, 40, 50, 20, 90] ,
        'background-color': "#FCA311",
        alpha: 1,
    },*/
    {
        values: [monthlySales[0], monthlySales[1], monthlySales[2], monthlySales[3], monthlySales[4], monthlySales[5], monthlySales[6], monthlySales[7], monthlySales[8], monthlySales[9], monthlySales[10], monthlySales[11] ],
        'background-color': "#8338EC",
        alpha: 1,
    }
     //{ for (let i = 0; i < ARRAY_LENGTH; i++) {
       //  values: [monthlySales[i]]
           
     //} }
    ]

    
};
// Zingchart render of the barchart
zingchart.render({
    id:'chartBar',
    data: chartData,
    height: 400,
    width: 600
});